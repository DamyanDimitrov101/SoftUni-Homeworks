﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Animal animal = new Animal("A");
            Reptile reptile= new Reptile("R");
            Mammal mammal = new Mammal("M");
            Lizard lizard = new Lizard("L");
            Snake snake= new Snake("S");
            Gorilla gorilla = new Gorilla("G");
            Bear bear = new Bear("B");

        }
    }
}