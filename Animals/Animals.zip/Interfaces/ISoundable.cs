﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals.Interfaces
{
    public interface ISoundable
    {
        string ProduceSound();
    }
}
