﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Animals.Enum
{
    public enum GenderEnum
    {
        Unknown = 0,
        Male = 1,
        Female = 2,
    }
}
