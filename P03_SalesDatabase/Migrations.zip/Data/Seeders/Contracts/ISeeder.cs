﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data.Seeders.Contracts
{
    public interface ISeeder
    {
        void Seed();

    }
}
