﻿using MXGP.Core.Contracts;
using System;
using System.Collections.Generic;
using System.Text;

namespace MXGP.Core
{
    internal class Engine : IEngine
    {
        public void Run()
        {

        }
    }
}
