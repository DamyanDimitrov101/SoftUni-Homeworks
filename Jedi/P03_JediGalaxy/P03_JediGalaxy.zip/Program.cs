﻿using System;
using System.Linq;

namespace P03_JediGalaxy
{
    class Program
    {
        static void Main()
        {
            var sum = new Core().Run();
            
            Console.WriteLine(sum);
        }

        
    }
}
