﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=USERPC\SQLEXPRESS;Database=BookShopDb;Trusted_Connection=True";
    }
}