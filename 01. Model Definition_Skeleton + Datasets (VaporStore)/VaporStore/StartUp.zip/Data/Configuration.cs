﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=USERPC\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}